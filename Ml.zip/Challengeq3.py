# question-4

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, accuracy_score
import numpy as np

# Generate some random data for demonstration
X = np.random.rand(100, 5)
y = np.random.randint(0, 2, size=100)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Logistic Regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)
y_pred_proba = model.predict_proba(X_test)

# Calculate Log Loss
logloss = log_loss(y_test, y_pred_proba)
print('Log Loss:', logloss)

# Calculate Accuracy
accuracy = accuracy_score(y_test, y_pred)
print('Accuracy:', accuracy)
