# question-Implement Anomaly Detection using k-means or Isolation Forest. Evaluate its effectiveness


import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest

# Generate some data
np.random.seed(42)
normal_data = np.random.randn(1000, 2) * 2
anomaly_data = np.concatenate([np.random.uniform(low=-10, high=10, size=(20, 2)),
                               np.random.uniform(low=20, high=30, size=(5, 2))], axis=0)
data = np.vstack([normal_data, anomaly_data])

# Fit the model
clf = IsolationForest(contamination=0.05, random_state=42)
clf.fit(data)

# Predict anomalies
y_pred = clf.predict(data)
normal_mask = y_pred == 1
anomaly_mask = y_pred == -1

# Plotting
plt.figure(figsize=(10, 6))
plt.scatter(data[normal_mask, 0], data[normal_mask, 1], c='green', label='Normal')
plt.scatter(data[anomaly_mask, 0], data[anomaly_mask, 1], c='red', label='Anomaly')
plt.title('Isolation Forest Anomaly Detection')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.legend()
plt.show()