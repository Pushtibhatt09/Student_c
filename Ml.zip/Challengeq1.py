# question 2
import numpy as np
import matplotlib.pyplot as plt


# Sample data
x = np.array([1, 2, 3, 4, 5])
y = np.array([2, 3, 4, 5, 6])

# Calculate the mean of x and y
x_mean = np.mean(x)
y_mean = np.mean(y)

# Calculate the terms needed for the slope (m) and y-intercept (b)
numerator = np.sum((x - x_mean) * (y - y_mean))
denominator = np.sum((x - x_mean)**2)

# Calculate slope (m) and y-intercept (b)
m = numerator / denominator
b = y_mean - m * x_mean

# Predicted values
y_pred = m * x + b

# Plotting the data points and the SLR line
plt.scatter(x, y, color='blue', label='Actual values')
plt.plot(x, y_pred, color='red', label='Predicted values')
plt.title('Simple Linear Regression')
plt.xlabel('X')
plt.ylabel('Y')
plt.legend()
plt.show()

# Evaluation
mse = np.mean((y_pred - y)**2)
print(f"Mean Squared Error: {mse}")

# Predicting for new values of x
new_x = 6
predicted_y = m * new_x + b
print(f"Predicted value for x={new_x}: {predicted_y}")
