# Parameter for the normal distribution
import numpy as np

# Set the mean and standard deviation
mean = int(input("Enter the number: "))
std_deviation = int(input("Enter the standard_deviation number: "))

# Generate 1000 random numbers from a normal distribution
random_numbers = np.random.normal(mean, std_deviation,)

# Print the generated numbers
print("Generated data from Normal Distribution :")
print(random_numbers)

# Parameter for the exponential distribution
scale = float(input("Enter the scale value: "))
num_samples = int(input("Enter the num_sample: "))
# Generate synthetic data from an exponential distribution
data_exponential = np.random.exponential(scale, num_samples)

# Print the generated data

print("Generated Data from Exponential Distribution:")
print(data_exponential)
