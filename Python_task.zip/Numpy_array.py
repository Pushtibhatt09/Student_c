#  question-Write a Python function using NumPy to calculate the mean of a given array.

import numpy as np

# Create a 1D array
arr = np.array([2, 7, 5, 8, 9, 4])
print("Original array:",arr)

# Calculate the mean of 1-D array
arr1 = np.mean(arr)
print("Arithmetic Mean of array:",arr1)