import pandas as pd
import numpy as np

dict = {
    'A': [1, 2, np.nan, 4, 5],
    'B': [np.nan, 2, 3, np.nan, 5],
    'C': [1, 2, 3, 4, 5]
}

# Create DataFrame
df = pd.DataFrame(dict)

# Calculate column means
column_means = df.mean()

# Replace NaN values with column means
for col in df.columns:
    col_mean = column_means[col]
    df[col] = df[col].fillna(col_mean)

print(df)