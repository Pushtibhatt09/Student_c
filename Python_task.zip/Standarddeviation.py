def calculate_mean(list):
    return sum(list) / len(list)

def calculate_variance(list):
    mean = calculate_mean(list)
    return sum((x - mean) ** 2 for x in list) / len(list)

def calculate_stddev(list):
    return round(calculate_variance(list) ** 0.5, 2)


num = [10,20,30,40,50]
std_deviation = calculate_stddev(num)
print("Standard Deviation:", std_deviation)