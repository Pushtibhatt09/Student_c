
import matplotlib.pyplot as plt
import pandas as pd

diabetes = pd.read_csv(r'C:\Users\darsh\Downloads\diabetes.csv')
X = diabetes.values[2]

plt.figure(figsize=(10,6))
plt.plot(X, color='red', label= 'Diabetes_data' )
plt.show()

plt.xlabel('Features X (Age)')
plt.ylabel('Target Variable (Diabetes Progression)')
plt.show()


