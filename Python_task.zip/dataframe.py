import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Example DataFrame
data = {
    'A': [1, 2 , 3 , 4 , 5],
    'B': [1, 2, 3, 4, 5]
}
df = pd.DataFrame(data)

# Select the column you want to normalize
column_to_normalize = 'A'

# Initialize the MinMaxScaler
scaler = MinMaxScaler()

# Fit and transform the column values
df[column_to_normalize] = scaler.fit_transform(df[[column_to_normalize]])

# Display the normalized DataFrame
print(df)