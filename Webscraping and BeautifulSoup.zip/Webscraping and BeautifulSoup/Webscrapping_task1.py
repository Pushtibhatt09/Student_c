# Task 1: Scrape Page Titles

# Extraction of page titles using BeautifulSoup.
# Display of the page titles in the output.
from bs4 import BeautifulSoup
import requests

link = input("Enter valid URL : ")
link_html = requests.get(link)
link_html_text = link_html.text
soup = BeautifulSoup(link_html_text, "lxml")
title = soup.find("title").text
print(f"Title is : {title}")