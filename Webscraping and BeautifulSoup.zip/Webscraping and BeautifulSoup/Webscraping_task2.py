#  task-2 Task 2: Extract and Display All Links
# Criteria:

# Extraction of all hyperlinks using BeautifulSoup.
# Display of all links in the output.
import requests
from bs4 import BeautifulSoup

# Prompt the user to enter a valid URL
link = input("Enter valid URL: ")

# Fetch the HTML content of the URL
link_html = requests.get(link)
link_html_text = link_html.text

# Parse the HTML using BeautifulSoup with lxml parser
soup = BeautifulSoup(link_html_text, "lxml")

# Find all anchor tags
all_links = soup.find_all("a")

# Print all the links that start with "https:"
print("\nAll the links are: ")
for link in all_links:
    if "https:" in link.get("href", ""):
        print(f"{link['href']} \n")
