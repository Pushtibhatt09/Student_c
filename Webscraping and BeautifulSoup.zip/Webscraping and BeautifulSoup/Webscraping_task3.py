# Task 3:Scrape Product Names and Prices from webSite.
# Website: Books to Scrape
import requests
from bs4 import BeautifulSoup

url = 'http://books.toscrape.com/'
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')
products = soup.find_all('article', class_='product_pod')
for product in products:

    title = product.h3.a['title']
    price = product.find('p', class_='price_color').text.strip()
    print(f"Product: {title}, Price: {price}")