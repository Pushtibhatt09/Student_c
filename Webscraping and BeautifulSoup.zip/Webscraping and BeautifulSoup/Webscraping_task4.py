# Task 4: Scrape Blog Post Titles and Dates
#
# Steps:Choose a blog homepage with multiple posts.
# Write a script to:
# Load the HTML content of the page.
# Extract blog post titles and publication dates.
# Print the extracted data.

import requests
from bs4 import BeautifulSoup
import datetime

url = 'https://thesidedishbyvedant.blogspot.com/'


response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')
post_containers = soup.find_all(['article', 'div'], class_='post')
posts = []
for container in post_containers:
    title = container.find('h3', class_='post-title').text.strip()
    date_str = container.find('time')['datetime']
    date = datetime.datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%S%z')
    posts.append((title, date))
for title, date in posts:
    print(f"Title: {title}, Date: {date.strftime('%Y-%m-%d')}")
